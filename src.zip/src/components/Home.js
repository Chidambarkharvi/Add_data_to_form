import React from 'react'

function Home(props) {
    return (
        <div>
     
     <div class="secondbody">
<div id="left_content"> <h1>Grow your business with us.</h1> 
<p>We are team of talented designers making websites with Bootstrap</p> <button class="left_button" >Get started</button></div>
<div  id="right_content" >  <img src="https://bootstrapmade.com/demo/templates/Vesperr/assets/img/hero-img.png"alt="img" /></div>
</div> 
        </div>
    )
}

export default Home
